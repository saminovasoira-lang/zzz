DURBEK MARKET — demo e-commerce loyiha

Ishga tushirish:
1. ZIP faylni oching.
2. index.html faylini Chrome orqali oching.
3. Xarita uchun internet kerak bo'ladi.

Imkoniyatlar:
- Mahsulot katalogi, qidiruv va kategoriyalar
- Savatcha va demo buyurtma berish
- OpenStreetMap xaritasi va filial markerlari
- Brauzer geolokatsiyasi orqali yaqin filialni topish
- Kuryer kabineti: kuryer ochiq buyurtmani o'zi tanlaydi
- Admin panel: buyurtmalar, statuslarni o'zgartirish, CSV eksport

Muhim:
Bu frontend demo. Ma'lumotlar shu brauzerning localStorage xotirasida saqlanadi.
Haqiqiy ishga tushirish uchun backend/API, ma'lumotlar bazasi, admin autentifikatsiyasi,
kuryer akkauntlari, serverdagi buyurtma sinxronizatsiyasi va to'lov integratsiyasi kerak.
Demo admin/kuryer tugmalari xavfsiz login bilan himoyalanmagan.
Filial koordinatalari Farg'ona shahri atrofidagi namunaviy nuqtalar; ularni o'zingizning
haqiqiy filial manzillaringizga almashtiring.
